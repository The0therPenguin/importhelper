class Other:
    def __init__(self):
        console.log("Created Other")
        pass